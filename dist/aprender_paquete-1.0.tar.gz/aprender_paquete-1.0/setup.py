from setuptools import setup

setup(
    name = "aprender_paquete",
    version ="1.0",
    description ="Paquete_preentrega2",
    author = "Luis Bibiano",
    author_email = "lmbibiano@gmail.com",
    packages = ["aprender_paquete"],
)

